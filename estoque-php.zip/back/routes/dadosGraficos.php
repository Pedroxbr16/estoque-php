<?php
require_once '../db.php';

error_log("Ação recebida: " . ($_GET['action'] ?? 'Nenhuma ação recebida'));

if (isset($_GET['action']) && $_GET['action'] === 'dadosgraficos') {
    try {
        $conn = getConnection(); // Verifica se a função getConnection está funcionando corretamente
        $query = "SELECT tipo_material, COUNT(*) AS total FROM estoque GROUP BY tipo_material";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        header('Content-Type: application/json');
        echo json_encode($result);
    } catch (PDOException $e) {
        echo json_encode(['error' => 'Erro ao buscar dados: ' . $e->getMessage()]);
    }
    exit;
} else {
    // Log para depuração
    error_log('Ação inválida recebida: ' . ($_GET['action'] ?? 'Nenhuma ação recebida'));
    echo json_encode(['error' => 'Ação inválida']);
    exit;
}
