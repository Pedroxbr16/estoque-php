document.addEventListener("DOMContentLoaded", function () {
    const chartContainer = document.querySelector('.chart-container');

    // Exibe mensagem de carregamento
    chartContainer.innerHTML = '<p>Carregando dados...</p>';

    // Busca os dados do endpoint dedicado
    fetch('../../back/routes/dadosGraficos.php')
        .then(async (response) => {
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Erro ao carregar dados do servidor: ${response.status} ${response.statusText} - ${errorText}`);
            }
            return response.json();
        })
        .then(data => {
            // Remove mensagem de carregamento e recria o canvas
            chartContainer.innerHTML = '<canvas id="tipoMaterialChart"></canvas>';
            const ctx = document.getElementById('tipoMaterialChart').getContext('2d');

            const labels = data.map(item => item.tipo_material);
            const valores = data.map(item => item.total);

            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Distribuição por Tipo de Material',
                        data: valores,
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.6)',
                            'rgba(54, 162, 235, 0.6)',
                            'rgba(255, 206, 86, 0.6)',
                            'rgba(75, 192, 192, 0.6)',
                            'rgba(153, 102, 255, 0.6)',
                            'rgba(255, 159, 64, 0.6)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)',
                            'rgba(75, 192, 192, 1)',
                            'rgba(153, 102, 255, 1)',
                            'rgba(255, 159, 64, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            callbacks: {
                                label: function (context) {
                                    const total = context.dataset.data.reduce((sum, value) => sum + value, 0);
                                    const percentage = ((context.raw / total) * 100).toFixed(2);
                                    return `${context.label}: ${context.raw} (${percentage}%)`;
                                }
                            }
                        }
                    }
                }
            });
        })
        .catch(error => {
            console.error('Erro detectado:', error.message);
            chartContainer.innerHTML = `<p class="text-danger">Erro ao carregar o gráfico: ${error.message}</p>`;
        });
});
